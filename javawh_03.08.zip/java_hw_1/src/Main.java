public class Main {
    public static void main(String[] args) {
        char mn = 'G';
        int nb = 89;
        byte bv = 4;
        short vc = 56;
        float cx = 4.7333436f;
        double xy = 4.355453532;
        long yl = 12121l;
        System.out.println(mn);
        System.out.println(nb);
        System.out.println(bv);
        System.out.println(vc);
        System.out.println(cx);
        System.out.println(xy);
        System.out.println(yl);

        System.out.println(" ");

        int i = 857;
        System.out.print(i + " -> ");
        System.out.print(i / 100 + ", ");
        System.out.print(i / 10 % 10 + ", ");
        System.out.print(i % 10 + ", ");











    }
}